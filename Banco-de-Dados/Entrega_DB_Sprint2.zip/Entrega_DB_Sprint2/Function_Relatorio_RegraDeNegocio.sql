/*
Primeiramente define um tipo de tabela que ser� utilizado para armazenar os resultados,
depois a fun��o gerar_relatorio_agendamentos_dia gera um relat�rio detalhado sobre tratamentos odontol�gicos agendados para cada dia, 
unindo dados de v�rias tabelas e exibindo informa��es organizadas. 

A fun��o usa PIPELINED para retornar os resultados linha por linha como uma tabela organizada, 
permitindo que outros processos consultem o relat�rio como uma tabela SQL normal.
*/


CREATE OR REPLACE TYPE relatorio_agendamentos_dia_extendido AS OBJECT (
    data_agendada       DATE,
    dentista            VARCHAR2(100),
    tratamentos_count   NUMBER,
    tipo_tratamento     VARCHAR2(50),
    descr_tratamento    VARCHAR2(255),
    usuario_responsavel VARCHAR2(100)
);

CREATE OR REPLACE TYPE tabela_relatorio_agendamentos_dia_extendido IS TABLE OF relatorio_agendamentos_dia_extendido;


CREATE OR REPLACE FUNCTION gerar_relatorio_agendamentos_dia
RETURN tabela_relatorio_agendamentos_dia_extendido PIPELINED
IS
    -- Vari�vel para armazenar os resultados da fun��o relatorio_tratamentos
    v_tratamentos tratamento_usuario_tab := relatorio_tratamentos();
BEGIN
    FOR r IN (
        SELECT 
            a.data_agendada,
            d.nome_dentista AS dentista,
            COUNT(a.id_agendamento) AS tratamentos_count,
            t.tipo_tratamento,
            t.descr_tratamento,
            t.nome_usuario AS usuario_responsavel
        FROM 
            c_op_agendamento a
        INNER JOIN 
            c_op_dentista d ON a.id_tratamento = d.id_dentista
        INNER JOIN 
            TABLE(v_tratamentos) t ON t.id_tratamento = a.id_tratamento
        GROUP BY 
            a.data_agendada, d.nome_dentista, t.tipo_tratamento, t.descr_tratamento, t.nome_usuario
        ORDER BY 
            a.data_agendada, d.nome_dentista
    ) LOOP
        PIPE ROW (
            relatorio_agendamentos_dia_extendido(
                r.data_agendada,
                r.dentista,
                r.tratamentos_count,
                r.tipo_tratamento,
                r.descr_tratamento,
                r.usuario_responsavel
            )
        );
    END LOOP;
    
    RETURN;
END gerar_relatorio_agendamentos_dia;




SELECT * FROM TABLE(gerar_relatorio_agendamentos_dia);

